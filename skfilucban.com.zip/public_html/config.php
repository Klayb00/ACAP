<?php

$conn = mysqli_connect('localhost','u888684055_sinagkalinga','K/5rNOHbh9','u888684055_capstone') or die('connection failed');

?>