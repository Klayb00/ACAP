<?php
// Set PHP timezone to Asia/Manila
date_default_timezone_set('Asia/Manila');

// Include database configuration
include 'config.php';
session_start();

// Get the logged-in user ID
$user_id = $_SESSION['user_id'];


// Get the medicine ID from the form
$medsID = intval($_POST['med_id']);

if (isset($_POST["update"])) {
    try {
        // Start a transaction
        mysqli_begin_transaction($conn);

        // Sanitize and fetch input values
        $item_name = mysqli_real_escape_string($conn, $_POST["itemName"]);
        $begin_balance = floatval($_POST["bgnblnc"]);
        $expirations_date = mysqli_real_escape_string($conn, $_POST["expirations_date"]);
        $price = floatval($_POST["prices"]);
        $donate = intval($_POST["donate"]);
        $out_items = intval($_POST["out_items"]);
        $sumStock = intval($_POST["addstock"]); // New stock being added
        $category = isset($_POST["medss"]) ? mysqli_real_escape_string($conn, $_POST["medss"]) : 'Others';

        // Fetch current stock
        $selectStockQuery = "SELECT begin_balance, begin_amount FROM medicine_data WHERE medicineID = $medsID";
        $resultStock = mysqli_query($conn, $selectStockQuery);

        if (!$resultStock || mysqli_num_rows($resultStock) == 0) {
            throw new Exception("Error: Item not found.");
        }

        $row = mysqli_fetch_assoc($resultStock);
        $currentStock = floatval($row['begin_balance']);
        $currentBeginAmount = floatval($row['begin_amount']);

        // Ensure stock is sufficient before deducting
        if ($currentStock < ($out_items + $donate)) {
            throw new Exception("Insufficient stock. You cannot deduct more than the available stock.");
        }

        // ✅ Correctly Calculate New Stock
        $newStock = $currentStock + $sumStock - $out_items - $donate;

        // ✅ Correctly Update `begin_amount`
        $stocksUpdate = $sumStock * $price;
        $newBeginAmount = $currentBeginAmount + $stocksUpdate;
        $total_outamount = ($donate + $out_items) * $price;

        // Ensure stock doesn't go negative
        if ($newStock < 0) {
            throw new Exception("Error: Stock calculation resulted in a negative value.");
        }

        $currentDateTime = date("Y-m-d H:i:s");

        // 🔥 Update stock in the `medicine_data` table
        $updateStockQuery = "UPDATE medicine_data 
                     SET begin_balance = $newStock, 
                         donate = donate + $donate, 
                         out_items = out_items + $out_items, 
                         out_amount = out_amount + $total_outamount,
                         begin_amount = $newBeginAmount,
                         updated_at = '$currentDateTime'  
                     WHERE medicineID = $medsID";

        if (!mysqli_query($conn, $updateStockQuery)) {
            throw new Exception("Failed to update stock: " . mysqli_error($conn));
        }

        // ✅ Fetch item size for records
        $selectSizeQuery = "SELECT item_size FROM medicine_data WHERE medicineID = $medsID";
        $resultSize = mysqli_query($conn, $selectSizeQuery);

        if (!$resultSize || mysqli_num_rows($resultSize) == 0) {
            throw new Exception("Error: Item size not found.");
        }

        $rowSize = mysqli_fetch_assoc($resultSize);
        $item_size = mysqli_real_escape_string($conn, $rowSize['item_size']);

        // ✅ Insert the `out_items` into `medicine_out_records`
        // ✅ Insert `out_items` into `medicine_out_records`
        if ($out_items > 0) {
            $total_cost = $out_items * $price;
            $insertOutItemsQuery = "INSERT INTO medicine_out_records (medicineID, user_id, item_name, out_items, donate, price, total_cost, date_out) 
                                    VALUES ($medsID, $user_id, '$item_name', $out_items, 0, $price, $total_cost, NOW())";
        
            if (!mysqli_query($conn, $insertOutItemsQuery)) {
                throw new Exception("Failed to insert out items record: " . mysqli_error($conn));
            }
        }
        
        // ✅ Insert `donate` into `medicine_out_records`
        if ($donate > 0) {
            $total_donation_cost = $donate * $price;
            $insertDonateQuery = "INSERT INTO medicine_out_records (medicineID, user_id, item_name, out_items, donate, price, total_cost, date_out) 
                                  VALUES ($medsID, $user_id, '$item_name', 0, $donate, $price, $total_donation_cost, NOW())";
        
            if (!mysqli_query($conn, $insertDonateQuery)) {
                throw new Exception("Failed to insert donation record: " . mysqli_error($conn));
            }
        }

        
        $userQuery = "SELECT uname FROM user_accounts WHERE id = $user_id";
        $resultUser = mysqli_query($conn, $userQuery);
        
        if ($resultUser && mysqli_num_rows($resultUser) > 0) {
            $rowUser = mysqli_fetch_assoc($resultUser);
            $username = mysqli_real_escape_string($conn, $rowUser['uname']);
        } else {
            $username = "Unknown"; // Default if no username is found
        }


        // ✅ Log the activity
        $action = 'Update';
        $target = 'Medicine Data';
        $description = "User $username updated stock for medicine ID $medsID. New stock: $newStock, Donation: $donate, Out Items: $out_items, Begin Amount: $newBeginAmount.";
        $description = mysqli_real_escape_string($conn, $description);
        $time = date("Y-m-d H:i:s");
        
        $logQuery = "INSERT INTO activity_log (user_id, username, action, medicine_name, target, description, time) 
                     VALUES ($user_id, '$username', '$action', '$item_name', '$target', '$description', '$time')";
        
        if (!mysqli_query($conn, $logQuery)) {
            throw new Exception("Failed to log activity: " . mysqli_error($conn));
        }


        // ✅ Commit the transaction
        mysqli_commit($conn);

        // ✅ Success message
        echo "<script>alert('Stock updated successfully. Remaining stock: $newStock.'); window.location.href='medicine_inventory.php';</script>";
    } catch (Exception $e) {
        // ❌ Rollback the transaction on error
        mysqli_rollback($conn);

        // ❌ Display the error message
        $error_message = htmlspecialchars($e->getMessage());
        echo "<script>alert('$error_message'); window.location.href='medicine_inventory.php';</script>";
    }
}
?>

