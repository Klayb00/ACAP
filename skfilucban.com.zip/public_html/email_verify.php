<?php

include 'config.php';

if (isset($_POST['verify'])) {
    if (isset($_GET['code'])) {
        // Sanitize inputs
        $activation_code = $_GET['code'];
        $otp = $_POST['otp']; // Trim the OTP to avoid any leading/trailing spaces

    
        // Fetch user details based on activation code
        $sqlSelect = "SELECT * FROM user_accounts WHERE activation_code = '".$activation_code."'"; 
        $resultSelect = mysqli_query($conn, $sqlSelect);

        if (mysqli_num_rows($resultSelect) > 0) {
            $rowSelect = mysqli_fetch_assoc($resultSelect);

            // Check OTP
            if ($rowSelect['otp'] !== $otp) {
                // Incorrect OTP, prompt for retry
                echo "<script>alert('Incorrect OTP. Please try again!')</script>";
            } else {
                // Update user record to activate account
                $sqlUpdate = "UPDATE user_accounts SET otp = '', email_status = 'active' WHERE otp = '".$otp."' AND activation_code = '".$activation_code."'";
                $resultUpdate = mysqli_query($conn, $sqlUpdate);

                if ($resultUpdate) {
                    // Successful activation
                    echo "<script>alert('Your account has been successfully activated. Redirecting to login page...');</script>";
                    header("Refresh:2; url=index.php");
                    exit;
                } else {
                    // Error while updating
                    echo "<script>alert('Failed to activate your account. Please contact support.')</script>";
                }
            }
        } else {
            // Invalid activation code
            echo "<script>alert('Invalid activation code. Redirecting to login page...');</script>";
            header("Refresh:2; url=email_verify.php");
            exit;
        }
    } else {
        // No activation code provided
        echo "<script>alert('No activation code provided. Redirecting to login page...');</script>";
        header("Refresh:2; url=index.php");
        exit;
    }
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="500; url=index.php">
    <title>Registration Page | Sinag Kalinga</title>
    <link rel="stylesheet" href="Css/logcss.css">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/5ad3914b72.js" crossorigin="anonymous"></script>

    <style>
        /* General Styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.otpform {
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 90%;
    max-width: 400px;
    padding: 20px;
    box-sizing: border-box;
}

.otpform h2 {
    margin: 0 0 20px;
    text-align: center;
    color: #333333;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-size: 14px;
    color: #555555;
    margin-bottom: 5px;
}

.form-group input[type="text"],
.form-group input[type="submit"] {
    width: 100%;
    padding: 10px;
    font-size: 14px;
    border: 1px solid #cccccc;
    border-radius: 5px;
    box-sizing: border-box;
    outline: none;
}

.form-group input[type="text"]:focus {
    border-color: #007bff;
}

.form-group input[type="submit"] {
    background-color: #007bff;
    color: white;
    cursor: pointer;
    border: none;
    transition: background-color 0.3s;
}

.form-group input[type="submit"]:hover {
    background-color: #0056b3;
}

/* Responsive Design */
@media (max-width: 768px) {
    .otpform {
        padding: 15px;
    }

    .otpform h2 {
        font-size: 20px;
    }

    .form-group input[type="text"],
    .form-group input[type="submit"] {
        font-size: 13px;
    }
}

@media (max-width: 480px) {
    .otpform {
        padding: 10px;
    }

    .otpform h2 {
        font-size: 18px;
    }

    .form-group input[type="text"],
    .form-group input[type="submit"] {
        font-size: 12px;
        padding: 8px;
    }
}

    </style>
</head>
<body>
    <div class="otpform">
        <h2>OTP VERIFY</h2>
        <form action="" method="POST">
            <div class="form-group">
                <label>OTP</label>
                <input type="text" name="otp" placeholder="Enter OTP to verify email" autocomplete="off" required>
            </div>
            <div class="form-group">
                <label></label>
                <input type="submit" name="verify" value="Verify">
            </div>
        </form>
    </div>
                
    <script src="Css/tryy.js"></script>
</body>
</html>
