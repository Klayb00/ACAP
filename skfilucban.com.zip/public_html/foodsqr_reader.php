<?php
session_start();
//Php connect
include 'config.php';

$user_id = $_SESSION['user_id'];

date_default_timezone_set('Asia/Manila');

if (isset($_POST["submit"])) {
    // Retrieve form data
    $f_category = mysqli_real_escape_string($conn, $_POST["category"]);
    $f_itemname = mysqli_real_escape_string($conn, $_POST["f_itemname"]);
    $f_size = mysqli_real_escape_string($conn, $_POST["size"]);
    $f_begin_balance = (float) $_POST["f_beginbalance"]; // Ensure it's numeric
    $f_expirations_date = mysqli_real_escape_string($conn, $_POST["expirations_date"]);
    $f_price = (float) $_POST["f_prices"]; // Ensure it's numeric

    // Calculate total amount
    $f_totaloutamount = $f_begin_balance * $f_price;
    $current_time = date("Y-m-d H:i:s");
    // Corrected SQL Query with properly formatted values
    $f_query_general = "INSERT INTO foodsutilities_inventory 
        (category, f_itemname, f_size, f_beginbalance, f_expirationdates, f_price, f_beginamount, created_at) 
        VALUES 
        ('$f_category', '$f_itemname', '$f_size', $f_begin_balance, '$f_expirations_date', $f_price, $f_totaloutamount, '$current_time')";

    // Execute the query
    $f_resultquery = mysqli_query($conn, $f_query_general);

    if ($f_resultquery) {
        header('Location: foods&utilities_inventory.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Scanner with Popup Form</title>
    <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f8ff;
            background-size: cover; /* Ensures the image covers the entire page */
            background-repeat: no-repeat; /* Prevents the image from repeating */
            background-position: center; /* Centers the image on the page */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333; /* Optional: Adjust text color for better readability */
        }
         #scanner {
            width: 70%;
            height: 50%;
            display: flex;
            align-items: center;
            border-radius: 10px;
            border: 10px solid #00C0CC;
        }

        /* Modal (Popup) Styles */
        .modal {
            display: none;
            position: absolute;
            min-width: 50%;
            transition: cubic-bezier(0.075, 0.82, 0.165, 1);
        }

        .modal-content {
            flex-direction: column;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%); /* Center the form */
            background-image: linear-gradient(150deg, #00F0FF, #00D8E5, #00C0CC, #D3CC23);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            max-width: 400px; /* Increased max width */
            width: 95%; /* Make it fill most of the screen on smaller devices */
            padding: 30px; 
            color: #fff;
            border-radius: 8px;
        }
        .modal-content input{
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            gap: 10px;
            border-radius: 5px;
            width: 100%; /* Full width for better responsiveness */
            box-sizing: border-box;
        }
        .modal-content select{
            border: none;
            background: #f1f1f1;
            padding-right: 40%;
            padding-top: 10px;
            padding-bottom: 10px;
            margin-bottom: 15px;
  }
  .modal-content label{
    color: black;
    font-size: 15px;
  }
  .modal-content .btn:hover, .open-button:hover {
    opacity: 1;
  }
    .modal-content button{
        display: flex;
        justify-content: center;
        width: 100%;
        padding: 10px;
        background-color:rgb(123, 194, 252);
    }
        /* Close button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
<br>
    <br>
    <br>
    <br>
    <br>
    <br>
<center>
<h1>QR Code Scanner</h1>
<button onclick="goBack()" style="margin-bottom: 20px; padding: 10px 20px; background-color: #007bff; color: #fff; border: none; border-radius: 5px; cursor: pointer;">
            Back
        </button>
   
<!-- QR Code Scanner Video -->
<video id="scanner" width="600" height="400" autoplay></video>
</center>


<!-- Hidden Modal Form -->
<!-- Hidden Modal Form -->
<div id="qrModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeModal">&times;</span>
        <h2>Add Supply</h2>
        <form id="qrForm" method="POST">
            <p>QR Code Data: <span id="f_itemname">No QR code detected</span></p>
            <br>
            <label for="category" class="form-label">Category:</label>
            <input type="text" id="qrCodeCategoryInput" name="category" class="form-control" placeholder="Category" required>
            <br>
            <label for="f_itemname">Item Name</label>
            <br>
            <input type="text" id="qrCodeDataInput" name="f_itemname" value="">
            <br>
            <label for="f_beginbalance">Beginning Balances</label>
            <br>
            <input type="text" name="f_beginbalance" required>
            <br>
            <label for="sizeInput">Size</label>
            <br>
            <input type="text" id="sizeInput" name="size" required>
            <br>
            <label for="expirations_date">Expiration Date</label>
            <br>
            <input type="date" name="expirations_date" required>
            <br>
            <label for="f_prices">Price</label>
            <br>
            <input type="text" name="f_prices" required>
        
            <button type="submit" name="submit">Add Supply</button>
        </form>
    </div>
</div>

<script>
    function goBack() {
        window.history.back();
    }

    const videoElement = document.getElementById("scanner");
    const qrModal = document.getElementById("qrModal");
    const closeModal = document.getElementById("closeModal");
    const qrCodeDataInput = document.getElementById("qrCodeDataInput");
    const qrCodeCategoryInput = document.getElementById("qrCodeCategoryInput");
    const sizeInput = document.getElementById("sizeInput"); // Added reference to size input

    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
        .then(stream => {
            videoElement.srcObject = stream;
            videoElement.play();
            scanQRCode();
        })
        .catch(err => console.error("Webcam access error:", err));

    function scanQRCode() {
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");

        (function processFrame() {
            if (videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) {
                canvas.width = videoElement.videoWidth;
                canvas.height = videoElement.videoHeight;
                context.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

                const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                const code = jsQR(imageData.data, canvas.width, canvas.height);

                if (code) {
                    populateFormFields(code.data);
                    qrModal.style.display = "block";
                }
            }
            requestAnimationFrame(processFrame);
        })();
    }

    function populateFormFields(qrData) {
        try {
            // Check if QR data is JSON or simple text
            let parsedData;
            try {
                parsedData = JSON.parse(qrData);
            } catch (error) {
                parsedData = { text: qrData }; // treat as plain text if JSON parse fails
            }

            qrCodeDataInput.value = parsedData.text || "";
            qrCodeCategoryInput.value = parsedData.category || "";
            sizeInput.value = parsedData.size || ""; // Populate size if available in QR data
        } catch (error) {
            console.error("Error parsing QR data:", error);
            alert("Invalid QR Code format. Make sure it contains valid JSON data.");
        }
    }

    closeModal.onclick = () => qrModal.style.display = "none";
    window.onclick = event => {
        if (event.target == qrModal) qrModal.style.display = "none";
    };
</script>



</body>
</html>
