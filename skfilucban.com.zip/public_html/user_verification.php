<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
    header('location:login.php');
 };
 
 if(isset($_GET['logout'])){
    unset($user_id);
    session_destroy();
    header('location:login.php');
 }

                if(isset($_POST['approve'])){
                    $id = $_POST['id'];

                    $select = "UPDATE user_accounts SET status = 'approved' WHERE id = '$id'";
                    $result = mysqli_query($conn, $select);
                    header('location:admin_approval.php');
                }

                if(isset($_POST['deny'])){
                    $id = $_POST['id'];

                    $select = "DELETE FROM user_accounts  WHERE id = '$id'";
                    $result = mysqli_query($conn, $select);
                    header('location:admin_approval.php');
                }
            ?>